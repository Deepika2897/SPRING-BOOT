package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;

public interface EmployeeService {

	Employee saveEmployee(Employee employee);

	List<Employee> fetchEmployeeList();

	

	Employee fetchEmployeeByName(String ename);

	Employee fetchEmployeeByAge(Integer eage);

	Employee fetchEmployeeBySalary(Double esalary);

	Employee fetchEmployeeByMobno(String emobno);

	Employee updateEmployee(Integer eid, Employee employee) throws EmployeeNotFoundException;

	

	

	Employee fetchEmployeeById(Integer eid) throws EmployeeNotFoundException;

	void deleteEmployeeById(Integer eid) throws EmployeeNotFoundException;

	//Employee fetchEmployeeById(Integer eid);

	

	

}
