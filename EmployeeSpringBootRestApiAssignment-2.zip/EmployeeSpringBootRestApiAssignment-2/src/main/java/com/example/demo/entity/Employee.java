package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

@Entity
public class Employee {
@Id
@GeneratedValue(generator = "seq", strategy = GenerationType.AUTO)
@SequenceGenerator(name="seq", initialValue = 1000)
private Integer employeeId;
@NotNull(message="Employee name cannot be null")
@NotBlank(message="Employee name cannot be blank")
private String employeeName;
@Range(min = 21, message = "Employee age cannot be less than 21 years")
private Integer employeeAge;
@Column(unique = true)
@Length(min=10, max=13, message="Cell number cannot be less than 10 characters")
private String employeeMobno;
private Double employeeSalary;
public Employee() {
	super();
}
public Employee(Integer employeeId, String employeeName, Integer employeeAge, String employeeMobno,
		Double employeeSalary) {
	super();
	this.employeeId = employeeId;
	this.employeeName = employeeName;
	this.employeeAge = employeeAge;
	this.employeeMobno = employeeMobno;
	this.employeeSalary = employeeSalary;
}
public Integer getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(Integer employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public Integer getEmployeeAge() {
	return employeeAge;
}
public void setEmployeeAge(Integer employeeAge) {
	this.employeeAge = employeeAge;
}
public String getEmployeeMobno() {
	return employeeMobno;
}
public void setEmployeeMobno(String employeeMobno) {
	this.employeeMobno = employeeMobno;
}
public Double getEmployeeSalary() {
	return employeeSalary;
}
public void setEmployeeSalary(Double employeeSalary) {
	this.employeeSalary = employeeSalary;
}
@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAge=" + employeeAge
			+ ", employeeMobno=" + employeeMobno + ", employeeSalary=" + employeeSalary + "]";
}
}