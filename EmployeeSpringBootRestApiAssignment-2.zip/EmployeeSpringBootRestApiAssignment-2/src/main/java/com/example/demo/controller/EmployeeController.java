package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.entity.Employee;

import com.example.demo.error.EmployeeNotFoundException;
import com.example.demo.service.EmployeeService;

@RestController
public class EmployeeController {
@Autowired
EmployeeService employeeservice;
//inserting the records
@PostMapping("/employees/")
public Employee saveEmployee(@RequestBody Employee employee)
{
	return employeeservice.saveEmployee(employee);
}
//getting the whole records
@GetMapping("/employees/")
public List<Employee>fetchEmployeeList()
{
	return employeeservice.fetchEmployeeList();
}
/*getting the records based on BYID
		@GetMapping("/employees/{id}")
		public Employee fetchEmployeeById(@PathVariable("id") Integer eid)  {
			return employeeservice.fetchEmployeeById(eid);
		}*/

//getting the records based on BYID
		@GetMapping("/employees/{id}")
		public Employee fetchEmployeeById(@PathVariable("id") int eid) throws EmployeeNotFoundException {
			return employeeservice.fetchEmployeeById(eid);
		}

//getting the records based on BYNAME
@GetMapping("/employees/name/{name}")
public Employee fetchEmployeeByName(@PathVariable("name") String ename)
{
	return employeeservice.fetchEmployeeByName(ename);
}

//getting the records based on BYAGE
@GetMapping("/employees/age/{age}")
public Employee fetchEmployeeByAge(@PathVariable("age") Integer eage)
{
	return employeeservice.fetchEmployeeByAge(eage);
}
//getting the records based on BYSALARY
@GetMapping("employees/salary/{salary}")
public Employee fetchEmployeeBySalary(@PathVariable("salary") Double esalary)
{
	return employeeservice.fetchEmployeeBySalary(esalary);
}
//getting the records based on BYMOBNO
@GetMapping("employees/mobno/{mobno}")
public Employee fetchEmployeeByMobno(@PathVariable("mobno") String emobno)
{
	return employeeservice.fetchEmployeeByMobno(emobno);
}




//Updating the records
@PutMapping("/employees/{id}")

public Employee updateEmployee(@PathVariable ("id") Integer eid, @RequestBody Employee employee) throws EmployeeNotFoundException {
	  
	  return employeeservice.updateEmployee(eid,employee);
}
//deleting the records based on BYID
@DeleteMapping("/employees/{id}")

	 public String deleteEmployeeById (@PathVariable("id") Integer eid) throws EmployeeNotFoundException {
	  employeeservice.deleteEmployeeById(eid);
	  return "Employee is deleted";
	 
} 
}



