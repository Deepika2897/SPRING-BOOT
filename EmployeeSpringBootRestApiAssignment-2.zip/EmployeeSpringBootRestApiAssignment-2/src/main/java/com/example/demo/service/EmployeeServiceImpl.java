package com.example.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.entity.Employee;

import com.example.demo.error.EmployeeNotFoundException;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl  implements EmployeeService{
	@Autowired
	EmployeeRepository employeerepo;
	//inserting the records
	@Override
	public Employee saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeerepo.save(employee);
	}

	//getting the whole records
	@Override
	public List<Employee> fetchEmployeeList() {
		// TODO Auto-generated method stub
		return employeerepo.findAll();
	}
	/*getting the records based on BYID
	@Override
	public Employee fetchEmployeeById(Integer eid) {
		// TODO Auto-generated method stub
		return employeerepo.findById(eid).get();
	}*/
	@Override
	public Employee fetchEmployeeById(Integer eid) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		//check for null
		Optional<Employee> employee1= employeerepo.findById( eid);//check in database
	      if(!employee1.isPresent()) {
	    	  throw new EmployeeNotFoundException("Employee not available");
	      }
		return employeerepo.findById(eid).get();
	}
	//getting the records based onBYNAME
	@Override
	public Employee fetchEmployeeByName(String ename) {
		// TODO Auto-generated method stub
		return employeerepo.findByEmployeeName(ename).get();
	}
	//getting the records based on BYAGE
	@Override
	public Employee fetchEmployeeByAge(Integer eage) {
		// TODO Auto-generated method stub
		return employeerepo.findByEmployeeAge(eage).get();
	}
	//getting the records based on BYSALARY

	@Override
	public Employee fetchEmployeeBySalary(Double esalary) {
		// TODO Auto-generated method stub
		return employeerepo.findByEmployeeSalary(esalary).get();
	}
	//getting the records based on BYMOBNO
	@Override
	public Employee fetchEmployeeByMobno(String emobno) {
		// TODO Auto-generated method stub
		return employeerepo.findByEmployeeMobno(emobno).get();
	}
	//updating the records based on BYID
	@Override
	public Employee updateEmployee(Integer eid, Employee employee) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Employee> employee1= employeerepo.findById( eid);
		Employee empDB=null;
		if(employee1.isPresent()) {
			empDB=	employeerepo.findById( eid).get();
			if(Objects.nonNull(employee.getEmployeeName()) && !"".equalsIgnoreCase(employee.getEmployeeName())) {
				empDB.setEmployeeName(employee.getEmployeeName());

			}
			if(Objects.nonNull(employee.getEmployeeAge()) && !"".equals(employee.getEmployeeAge())) {
				empDB.setEmployeeAge(employee.getEmployeeAge());
				System.out.println(employee.getEmployeeAge());
			}
			if(Objects.nonNull(employee.getEmployeeSalary()) && !"".equals(employee.getEmployeeSalary())) {
				empDB.setEmployeeSalary(employee.getEmployeeSalary());
				System.out.println(employee.getEmployeeSalary());
			}
			if(Objects.nonNull(employee.getEmployeeMobno()) && !"".equals(employee.getEmployeeMobno())) {
				empDB.setEmployeeMobno(employee.getEmployeeMobno());
				System.out.println(employee.getEmployeeMobno());
			}


			return employeerepo.save(empDB);

		}
		else
		{
			throw new EmployeeNotFoundException("Employee is not found");
		}
	}
	/*//deleting the records
	@Override
	public void deleteEmployeeById(int eid) {
		// TODO Auto-generated method stub
		employeerepo.deleteById((long) eid);
	}*/
	@Override
	public void deleteEmployeeById(Integer eid) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		//check for null
		Optional<Employee> employee1= employeerepo.findById(eid);//check in database
          if(!employee1.isPresent()) {
        	  throw new EmployeeNotFoundException("Employee not available");
          }
          else {
		 employeerepo.deleteById( eid);
          }
	}

	
}
