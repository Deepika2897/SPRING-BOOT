package com.example.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Department;
import com.example.demo.error.DepartmentNotFoundException;
import com.example.demo.repository.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentRepository departmentrepo;

	//inserting the records
	@Override
	public Department saveDepartment(Department department) {
		// TODO Auto-generated method stub
		return departmentrepo.save(department);
	}

	//getting the records
	@Override
	public List<Department> fetchDepartmentList() {
		// TODO Auto-generated method stub
		return departmentrepo.findAll();
	}
	
	/*//getting the record based on BYID
		@Override
		public Department fetchDepartmentById(Long did) {
			
			
				return departmentrepo.findById(did).get();
			}*/


@Override
	public Department fetchDepartmentById(Long did) throws DepartmentNotFoundException {
		// TODO Auto-generated method stub
		//check for null
		Optional<Department> department1= departmentrepo.findById(did);//check in database
          if(!department1.isPresent()) {
        	  throw new DepartmentNotFoundException("Department not available");
          }
		return departmentrepo.findById(did).get();
}
		
		
		//getting the record based on BYNAME
		@Override
		public Department fetchDepartmentByName(String dname) {
			// TODO Auto-generated method stub
			return departmentrepo.findByDepartmentName(dname);
		}
		//getting the record based on BYCODE
		@Override
		public Department fetchDepartmentByCode(String dcode) {
			// TODO Auto-generated method stub
			return departmentrepo.findByDepartmentCode(dcode);
		}
		//getting the records based on BYADDRESS
		
		
		@Override
		public Department fetchDepartmentByAddress(String daddress) {
			// TODO Auto-generated method stub
			return departmentrepo.findByDepartmentAddress(daddress);
		}
		
		
	
	/*//deleting the records BYID
	@Override
	public void deleteDepartmentById(Long did) {
		// TODO Auto-generated method stub
		departmentrepo.deleteById(did);
	}*/

		@Override
		public void deleteDepartmentById(Long did) throws DepartmentNotFoundException {
			// TODO Auto-generated method stub
			//check for null
			Optional<Department> department1= departmentrepo.findById(did);//check in database
	          if(!department1.isPresent()) {
	        	  throw new DepartmentNotFoundException("Department not available");
	          }
	          else {
			 departmentrepo.deleteById(did);
	          }
		}


	
	
	
	
/*//updating the records
	@Override
	public Department updateDepartment(Long did, Department department) {
		// TODO Auto-generated method stub
		Optional<Department> department1= departmentrepo.findById(did);
		Department depDB=null;
		if(department1.isPresent()) {
			depDB=	departmentrepo.findById(did).get();
			if(Objects.nonNull(department.getDepartmentName()) && !"".equalsIgnoreCase(department.getDepartmentName())) {
				depDB.setDepartmentName(department.getDepartmentName());

			}
			if(Objects.nonNull(department.getDepartmentAddress()) && !"".equalsIgnoreCase(department.getDepartmentAddress())) {
				depDB.setDepartmentAddress(department.getDepartmentAddress());
				System.out.println(department.getDepartmentAddress());
			}
			if(Objects.nonNull(department.getDepartmentCode()) && !"".equalsIgnoreCase(department.getDepartmentCode())) {
				depDB.setDepartmentCode(department.getDepartmentCode());
				System.out.println(department.getDepartmentCode());
			}

		}
		return departmentrepo.save(depDB);


	}*/

		@Override
		public Department updateDepartment(Long did, Department department) throws DepartmentNotFoundException {
			Optional<Department> department1= departmentrepo.findById(did);//check in database
			Department depDB=null;
			if(department1.isPresent()) {
			 depDB=	departmentrepo.findById(did).get();
			if(Objects.nonNull(department.getDepartmentName()) && !"".equalsIgnoreCase(department.getDepartmentName())) {
				depDB.setDepartmentName(department.getDepartmentName());
				
			}
			if(Objects.nonNull(department.getDepartmentAddress()) && !"".equalsIgnoreCase(department.getDepartmentAddress())) {
				depDB.setDepartmentAddress(department.getDepartmentAddress());
				System.out.println(department.getDepartmentAddress());
			}
			if(Objects.nonNull(department.getDepartmentCode()) && !"".equalsIgnoreCase(department.getDepartmentCode())) {
				depDB.setDepartmentCode(department.getDepartmentCode());
				System.out.println(department.getDepartmentCode());
			}
			
			return departmentrepo.save(depDB);
			}
			else {
				throw new DepartmentNotFoundException("Department Not available");
			}
	        
		}

	
		}
	



	





