package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Department;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {
//findAll()//getting all the records
	//deleteById() //deleting based on id
	//FindById()//getting the record based on id
	Department findByDepartmentName(String dname);//getting the record based on name

	Department findByDepartmentCode(String dcode);//getting the record based on code

	Department findByDepartmentAddress(String daddress);//getting the record based on address

	
}
